package com.ujian.des31.driver.utils;

public class Utility {
	public static int testCount = 0;
}
